﻿# QR-Code-generator

QR-Code Generator is a web application built with HTML, CSS, Javascript and TailwindCSS to generate a QR code for any inputed website address.

To run the application, navigate to the project directory and run the following code:

npm install

The Application is hosted using Github. You can view the live version @ [https://elijahjohnny.github.io/QR-Code-generator/]

Always remember to modify the 'Tailwind.config.js' file for your root.

Since you have to always 'watch it', run this for this particular project (the .css varies per project)
"npx tailwindcss -i styles.css -o ./dist/output.css --watch"

Thanks for Checking this out 🤗
